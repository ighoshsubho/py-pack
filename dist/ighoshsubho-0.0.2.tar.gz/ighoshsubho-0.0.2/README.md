{
    "About" : "Hi, Subho this side 👋",
    "I'm" : "Into ML and Backend Development",
    "Learning" : "Neural Networks and Deep learning",
    "Loves to" : "Explore different technologies",
    "Reach me at" : "ighoshsubho@gmail.com"
    "Ride the space skyway home to 80s Miami" : "https://linktr.ee/ighoshsubho"
}