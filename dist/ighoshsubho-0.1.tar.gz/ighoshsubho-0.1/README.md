```
$ pip install ighoshsubho
Collecting ighoshsubho
  Downloading ighoshsubho-0.1.tar.gz (5.7 kB)
  Preparing metadata (setup.py) ... done

Installing collected packages: ighoshsubho
Successfully installed ighoshsubho-0.1

$ python

>>> from ighoshsubho import README
>>> README.md()

{
    "About" : "Hi, Subho this side 👋",
    "I'm" : "Into ML and Backend Development",
    "Learning" : "Neural Networks and Deep learning",
    "Loves to" : "Explore different technologies",
    "Reach me at" : "ighoshsubho@gmail.com",
    "Ride the space skyway home to 80s Miami" : "https://linktr.ee/ighoshsubho"
}

>>> exit()
```